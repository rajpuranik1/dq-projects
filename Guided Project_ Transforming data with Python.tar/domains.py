import read

if __name__ == "__main__":
    hn_stories = read.load_data()
    domains = hn_stories["url"]
    domain_counts = domains.value_counts()
    print(domain_counts[:100])
