import read
from dateutil.parser import parse
def get_hour(ts):
    dt = parse(ts)
    return dt.hour

if __name__== "__main__":
    hs_data = read.load_data()
    hs_data["submission_hours"] = hs_data["submission_time"].apply(get_hour)
    hour_counts = hs_data["submission_hours"].value_counts()
    print(hour_counts) 
