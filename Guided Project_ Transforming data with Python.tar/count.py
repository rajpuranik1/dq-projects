import read
from collections import Counter
if __name__ == "__main__":
    hn_stories = read.load_data()
    words = ""
    for i,v in enumerate(hn_stories["headline"]):
        words += str(v) + " "
    word_counts = Counter(words.lower().split())
    print(word_counts.most_common(100))
